require('./files/jquery.min');
require('./files/sweetalert.min');