require('./files/bootstrap.min');
// require('./files/mdb.min');
// require('./files/aos');
require('./files/script');
require('./files/popper.min');
require('./files/sweetalert.min');