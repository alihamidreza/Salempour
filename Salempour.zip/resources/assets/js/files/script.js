$(document).ready(function () {
   $('.categoryHead').click(function () {
      $('.backSubCat').slideToggle('slow');
   });
});