$(document).ready(function () {
   $('.categoryHead').click(function () {
      $('.backSubCat').slideToggle('slow');
   });

   // $('#scrolldown').click(function () {
   //    alert('salam');
   // })
});