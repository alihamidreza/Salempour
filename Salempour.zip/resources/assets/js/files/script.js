$(document).ready(function () {
   $('.categoryHead').click(function () {
      $('.backSubCat').fadeToggle('fast');
   });
});