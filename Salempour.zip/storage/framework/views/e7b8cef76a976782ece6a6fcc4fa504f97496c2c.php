<?php $__env->startSection('content'); ?>
    <h3>
        ویرایش مقاله
    </h3>
    <hr>
    <?php echo $__env->make('errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <form action="<?php echo e(route('articles.update' , $article->slug)); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PATCH')); ?>

        <div class="form-group">
            <label for="title">عنوان</label>
            <input type="text" class="form-control" id="title" placeholder="عنوان را وارد کنید" name="title"
                   value="<?php echo e($article->title); ?>">
        </div>
        <div class="form-group">
            <label for="writer">نویسنده</label>
            <input type="text" class="form-control" id="writer" placeholder="نویسنده را وارد کنید" name="writer"
                   value="<?php echo e($article->writer); ?>">
        </div>
        <div class="form-group">
            <label for="tags">تگ ها</label>
            <input type="text" class="form-control" id="tags" placeholder="تگ ها را وارد کنید" name="tags"
                   value="<?php echo e($article->tags); ?>">
        </div>
        <div class="form-group">
            <label for="images">ویرایش عکس</label>
            <input type="file" class="form-control" id="images" placeholder="عکس را را وارد کنید" name="images">
        </div>
            <div class="form-group">
            <img src="/<?php echo e($article->images['images']['321']); ?>">
        </div>
        <div class="form-group">
            <select class="form-control" name="category_id[]" multiple>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="body">متن</label>
            <textarea class="form-control" id="body" rows="6" name="body"
                      placeholder="متن را را وارد کنید"><?php echo e($article->body); ?></textarea>
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-success" value="ویرایش مقاله">
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>