<?php $__env->startComponent('mail::message'); ?>
    #فعال سازی ایمیل

<?php $__env->startComponent('mail::button' , ['url' => route('activation.account' , $activationCode)]); ?>
        فعال سازی
<?php echo $__env->renderComponent(); ?>

<?php echo $__env->renderComponent(); ?>
