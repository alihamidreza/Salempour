<?php $__env->startSection('content'); ?>
    <style>
        .backmenu{
            background: #d32f2f !important;
        }
    </style>
    <div style="background-image: url('images/photo_2016-05-29_21-08-50 (1).jpg'); background-repeat: no-repeat; background-size: cover; background-position: center center;background-attachment: fixed
">
<div class="container">
    <br>
    <br>
    <br>
    <br>
    <br>
    
    <div class="alert alert-info flex-center" style="text-align:center;">در حال حاضر امکان ثبت نام وجود ندارد . در بروزرسانی بعدی این مورد اصلاح میشود</div>
    <br>
    <br>
    <br>
    <br>
    <br>
</div>
    <div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>