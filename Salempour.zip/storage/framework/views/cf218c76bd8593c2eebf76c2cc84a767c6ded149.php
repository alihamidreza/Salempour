<?php $__env->startSection('title', 'موردی یافت نشد!'); ?>
<?php $__env->startSection('search'); ?>
<h1 class="font-weight-normal" style="font-size: 60px;">404</h1>
<br><br><br><br>
    <div class="container">
        <form action="<?php echo e(route('articles.search')); ?>" method="get">
            <div class="container">
                <input type="search" class="search col-md-10 col-xs-9"
                       placeholder="جستوجو کنید..." name="search">
            </div>
            <button type="submit" class="btnSearch col-md-2 col-xs-3"><i class="fa fa-search"></i></button>
        </form>
        <br>
        <br>
        <br>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('icon'); ?>
    <i class="fa fa-eye-slash"></i>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('message', 'موردی یافت نشد. لطفا موردی که دنبالش میگردید را دوباره جستوجو کنید'); ?>

<?php echo $__env->make('errors::layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>