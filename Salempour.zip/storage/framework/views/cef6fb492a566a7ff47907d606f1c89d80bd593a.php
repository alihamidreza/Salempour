<?php $__env->startSection('content'); ?>


    <div class="form-group">
        <h2 align="center">مقالات</h2>
    </div>
    <hr>
    <div class="left">
        <a href="<?php echo e(route('articles.create')); ?>" class="btn btn-primary">اضافه کردن مقاله</a>
    </div>
    <br>
    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
            <tr>
                <th>عنوان</th>
                <th>نویسنده</th>
                <th>متن</th>
                <th>کاربر</th>
                <th>تنظیمات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href=""><?php echo e($article->title); ?></a></td>
                    <td><?php echo e($article->writer); ?></td>
                    <td><?php echo e($article->body); ?></td>
                    <td><?php echo e($article->user->name); ?></td>
                    <td>
                        <div class="btn btn-group">
                            <form action="<?php echo e(route('articles.destroy' , $article->slug)); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field("DELETE")); ?>

                                <input type="submit" class="btn btn-danger" value="حذف">
                            </form>
                            <a href="<?php echo e(route('articles.edit' , $article->slug)); ?>" class="btn btn-warning">ویرایش</a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="align-items-center">
            <?php echo e($articles->render()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>