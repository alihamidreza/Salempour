<?php $__env->startSection('content'); ?>


    <div class="form-group">
        <h2 align="center">کاربران</h2>
    </div>
    <hr>
    <br>
    <div class="table-responsive">
        <table class="table table-striped table-sm">
            <thead>
            <tr>
                <th>نام</th>
                <th>ایمیل</th>
                <th>مقام</th>
                <th>تنظیمات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->level); ?></td>
                    <td>
                        <div class="btn btn-group">
                            <form action="<?php echo e(route('users.update' , $user->id)); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('PUT')); ?>

                                <?php if($user->active == 1): ?>
                                    <button type="submit" href="<?php echo e(route('users.update' , $user->id)); ?>" class="btn btn-danger" name="active_status" value="0">غیر فعال کردن</button>
                                <?php else: ?>
                                    <button type="submit" href="<?php echo e(route('users.update' , $user->id)); ?>" class="btn btn-success" name="active_status" value="1">فعال کردن</button>
                                <?php endif; ?>
                            </form>

                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="align-items-center">
            <?php echo e($users->render()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>