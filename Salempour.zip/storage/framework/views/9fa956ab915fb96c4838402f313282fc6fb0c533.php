<?php $__env->startSection('content'); ?>
    <h3>
        ثبت مقاله
    </h3>
    <hr>
    <?php echo $__env->make('errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <form action="<?php echo e(route('categories.store')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="name">نام</label>
            <input type="text" class="form-control" id="name" placeholder="نام را وارد کنید" name="name" value="<?php echo e(old('name')); ?>">
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-success" value="ثبت دسته">
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>