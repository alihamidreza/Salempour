<?php $__env->startSection('content'); ?>
    <style>
        .backmenu {
            background: #d32f2f !important;
        }
        .loginmenu{
            float: right;
            width: 100%;
            margin-top: 15px;
        }
    </style>
<section class="my-5 allPageSection">
    <br><br>

    <div class="container">
        
            
                
                    
                
                
            
        
    </div>
    <br>
    <div class="row flex-center">
        <?php echo e($products->render()); ?>

    </div>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="container" style="z-index: 1">
            <div class="col-md-6 col-sm-6 col-xs-12 col-lg-4" style="margin-top:15px;">
                <div class="card mb-2">
                    <div class="backImage">
                        <div class="loading">
                            <i class="fa fa-circle-o-notch fa-spin fa-3x fa-fw"></i>
                            <span class="sr-only">در حال بارگزاری...</span>
                        </div>
                    </div>
                    <a href="<?php echo e(route('products.single' , $product->slug)); ?>" class="imageStyle"> <img class="card-img-top " src="<?php echo e($product->images['images']['321']); ?>"
                                     alt="<?php echo e($product->title); ?>" height="241"></a>
                    <div class="card-body">
                        <span class="writer">نویسنده: <?php echo e($product->writer); ?></span>
                        <h4 class="card-title direction"><?php echo e($product->title); ?></h4>
                        <p class="card-text direction"><?php echo e(strip_tags(str_limit($product->body , 300))); ?></p>
                        <a class="btn btn-primary" href="<?php echo e(route('products.single' , $product->slug)); ?>">مشاهده محصول</a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="container flex-center" style="position: relative; top: 46px;">
        <?php echo e($products->render()); ?>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>