<?php $__env->startSection('content'); ?>
    <style>
        .backmenu {
            background: #d32f2f !important;
        }
        .loginmenu{
            float: right;
            width: 100%;
            margin-top: 15px;

        }
    </style>
<section class="my-5 allPageSection">
    <br><br>

    <div class="row">
        <div class="container">
            <h3 align="right">دسته بندی ها</h3>
            <hr>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <a href="<?php echo e(route('categories.show' , $category->name)); ?>" class="btn btn-outline-dark" style="float: right"><?php echo e($category->name); ?></a>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>