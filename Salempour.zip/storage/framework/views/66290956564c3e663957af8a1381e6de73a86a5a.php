<?php $__env->startSection('content'); ?>
    <h3>
        ویرایش دسته بندی
    </h3>
    <hr>
    <?php echo $__env->make('errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <form action="<?php echo e(route('categories.update' , $category->name)); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PATCH')); ?>

        <div class="form-group">
            <label for="name">عنوان</label>
            <input type="text" class="form-control" id="name" placeholder="نام را وارد کنید" name="name"
                   value="<?php echo e($category->name); ?>">
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-success" value="ویرایش دسته بندی">
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>