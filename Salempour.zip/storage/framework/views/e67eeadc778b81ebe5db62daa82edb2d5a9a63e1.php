<?php $__env->startSection('content'); ?>
    <style>
        .backmenu {
            background: #d32f2f !important;
        }
        .loginmenu{
            float: right;
            width: 100%;
            margin-top: 15px;
        }
    </style>

    <section class="my-5 allPageSection">
        <br><br>
        <div class="container">
            
            
            
            
            
            
            
            
        </div>
        <br>
        <br>

    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>